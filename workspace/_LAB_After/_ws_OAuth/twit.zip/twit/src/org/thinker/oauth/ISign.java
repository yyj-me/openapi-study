package org.thinker.oauth;

public interface ISign {

	public void sign();
}
