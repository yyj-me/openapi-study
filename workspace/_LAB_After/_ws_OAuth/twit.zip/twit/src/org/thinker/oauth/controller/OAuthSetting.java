package org.thinker.oauth.controller;

public class OAuthSetting {

	public static final String REQUEST_TOKEN_URL = 
	"http://tfactory.com:8000/tSimpleProvider/auth/request_token";
	public static final String CALLBACK_URL = 
		"http://jcornor.com:8000/twit/callback";
	public static final String CONSUMER_KEY = 
		"3cf9a576-6310-4bb8-831f-67a3dcaea660";
	public static final String CONSUMER_SECRET = 
		"9166f82f4092f1f9dd80e850788d6495";
	public static final String AUTHORIZE_URL = 
	"http://tfactory.com:8000/tSimpleProvider/auth/authorize";
	public static final String ACCESS_TOKEN_URL = 
	"http://tfactory.com:8000/tSimpleProvider/auth/access_token";

	// public static final String REQUEST_TOKEN_URL =
	// "https://api.twitter.com/oauth/request_token";
	// public static final String CALLBACK_URL =
	// "http://localhost:8000/twit/callback";
	// public static final String CONSUMER_KEY =
	// "mmoclZEjTFexE609T2EPQ";
	// public static final String CONSUMER_SECRET =
	// "hERucdmWEr3ZhKr3UKDwssoGLlIf3uX5Zolji3Bas";
	// public static final String AUTHORIZE_URL =
	// "https://api.twitter.com/oauth/authorize";
	// public static final String ACCESS_TOKEN_URL =
	// "https://api.twitter.com/oauth/access_token";

}
